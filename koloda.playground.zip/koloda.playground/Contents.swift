enum EnumenatinErrors:Error{
    case error400
    case error404
    case error500
}

var badRequest = false
var notFound = true
var internalServerError = false

func errorProcessing() throws{
    if badRequest{throw EnumenatinErrors.error400}
    if notFound{throw EnumenatinErrors.error404}
    if internalServerError{throw EnumenatinErrors.error500}
}
do {
    try errorProcessing()
} catch EnumenatinErrors.error400 {
    print("Hеправильный, некорректный запрос")
} catch EnumenatinErrors.error404{
    print("Hе найдено")
} catch EnumenatinErrors.error500{
    print("Bнутренняя ошибка сервера")
}

func comperation<K:Equatable>(_ a:K, _ b:K) -> String?{
    if a == b{
        print("Complete")
    }
return nil
}
comperation(2, 2)
